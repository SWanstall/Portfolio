//added getFullname and constructors
//F21SF - Monica
// Copied and adapted by Simon Wanstall
public class Name {
	private String firstName;
	private String middleName;
	private String lastName;

	// Creating variables for initials - Simon
	private char firstInitial;
	private char middleInitial;
	private char lastInitial;

	// constructor to create object with a first and last name
	public Name(String fName, String lName) {
		firstName = fName;
		middleName = "";
		lastName = lName;
	}

	// constructor to create object with first, middle and last name
	// if there isn't a middle name, that parameter could be an empty String
	public Name(String fName, String mName, String lName) {
		firstName = fName;
		middleName = mName;
		lastName = lName;
	}

	// Constructor for initials - Simon
	public Name(char fInitial, char mInitial, char lInitial) {

		firstInitial = fInitial;
		middleInitial = mInitial;
		lastInitial = lInitial;
	}

	// constructor to create name from full name
	// in the format first name then space then last name
	// or first name then space then middle name then space then last name
	public Name(String fullName) {
		int spacePos1 = fullName.indexOf(' ');
		firstName = fullName.substring(0, spacePos1);
		int spacePos2 = fullName.lastIndexOf(' ');
		if (spacePos1 == spacePos2)
			middleName = "";
		else
			middleName = fullName.substring(spacePos1 + 1, spacePos2);
		lastName = fullName.substring(spacePos2 + 1);

	}

	// returns the first name
	public String getFirstName() {
		return firstName;
	}

	// returns the last name
	public String getLastName() {
		return lastName;
	}

	// Returns initials - Simon
	public String getInitials() {

		firstInitial = firstName.charAt(0);
		lastInitial = lastName.charAt(0);

		if (!middleName.equals("")) {
			middleInitial = middleName.charAt(0);
			return firstInitial + "." + middleInitial + "." + lastInitial;
		} else {
			return firstInitial + "." + lastInitial;
		}
	}

	// returns the first name then a space then the last name
	public String getFirstAndLastName() {
		return firstName + " " + lastName;
	}

	// returns the last name followed by a comma and a space
	// then the first name
	public String getLastCommaFirst() {
		return lastName + ", " + firstName;
	}

	// returns the full name
	// either first name then space then last name
	// or first name then space then middle name then space
	// and then last name
	public String getFullName() {
		String result = firstName + " ";
		if (!middleName.equals("")) {
			result += middleName + " ";
		}
		result += lastName;

		return result;
	}
}
