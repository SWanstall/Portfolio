import java.nio.file.Path;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;

/**
 * This class manages the execution of all other classes via the CompetitorList
 * class.
 * 
 * @author Simon
 *
 */
public class Manager {

	/**
	 * Management method which controls the execution of all classes other than main
	 * to catch errors/exceptions.
	 */
	public static void managerFunction() {
		// Create variable to allow user input
		Scanner userInput = null;
		// Control the flow of the program while checking for errors and exceptions
		try {
			// Access the input file and parse data to useful formats via the CompetitorList
			// class
			CompetitorList csgoCompetitors = CompetitorList.parseFromFile(Path.of("src/CompetitorListCSGO.txt"), CompetitorType.CSGO);
			CompetitorList dotaCompetitors = CompetitorList.parseFromFile(Path.of("src/CompetitorList.txt"), CompetitorType.DOTA);
			CompetitorList dotaSoloCompetitors = CompetitorList.parseFromFile(Path.of("src/CompetitorListSolo.txt"), CompetitorType.DOTA_SOLO);
					
			CompetitorList competitors = CompetitorList.mergeLists(csgoCompetitors, dotaCompetitors, dotaSoloCompetitors);
			
			
			// User is presented with a choice: type ID number for short details or press
			// enter to write report to file
			System.out.print("Please enter an ID number or press enter for full report file: ");
			userInput = new Scanner(System.in);
			String userInputString = userInput.nextLine();
			// If user types anything, determine whether it is a valid ID, then print
			// details if valid
			if (userInputString.length() > 0) {
				Integer competitorNumber = Integer.parseInt(userInputString);
				Competitor competitor = competitors.findById(competitorNumber);
				if (competitor == null) {
					System.err.println("Could not find competitor with competitorNumber " + competitorNumber);
				} else {
					System.out.println(competitor.getShortDetails());
				}
				// Otherwise attempt to write the report file
			} else {
				try {
					// Write to existing text file
					FileWriter report = new FileWriter("src/CompetitorReport.txt");
					report.write(competitors.getTable());
					report.close();
					System.out.println("Report file written successfully!");
				} catch (IOException e) {
					// Indicate that the file could not be written along with the stack trace to aid
					// troubleshooting
					System.out.println("An error occurred. No file created.");
					e.printStackTrace();
				}

				try {
					// Write to existing text file
					FileWriter report = new FileWriter("src/CompetitorShortReport.txt");
					report.write(competitors.getShortTable());
					report.close();
					System.out.println("Short report file written successfully!");
				} catch (IOException e) {
					// Indicate that the file could not be written along with the stack trace to aid
					// troubleshooting
					System.out.println("An error occurred. No file created.");
					e.printStackTrace();
				}
				
			}
		} catch (NumberFormatException e) {
			// Specify that the user should use a number to rectify this error
			System.err.println("Invalid input! Expected a number");

		} catch (Exception e) {
			// Catch all other exceptions and indicate where they have arisen
			System.out.println("Error in:");
			System.out.println(e.getLocalizedMessage());

		} finally {
			// If user supplies input, stop taking inputs
			if (userInput != null) {
				userInput.close();
			}
		}
	}
	

}
