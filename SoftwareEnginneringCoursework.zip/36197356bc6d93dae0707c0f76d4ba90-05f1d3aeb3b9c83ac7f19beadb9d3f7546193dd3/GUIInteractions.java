import java.io.*;
import java.nio.file.Path;
public class GUIInteractions {
	
	private CompetitorList entries;
	
    public GUIInteractions() 
    {
    	//initialise empty list of staff
        entries = new CompetitorList();
        addCompetitor();
    }
    
    private void addCompetitor() {
        //load staff data from file
        BufferedReader buff = null;
        try {
        	buff = new BufferedReader(new FileReader("src/CompetitorList.txt"));
	    	String inputLine = buff.readLine();  //read first line
	    	while(inputLine != null){  
	    		processLine(inputLine);
	            //read next line
	            inputLine = buff.readLine();
	        }
        }
        catch(FileNotFoundException e) {
        	System.out.println(e.getMessage());
            System.exit(1);
        }
        catch (IOException e) {
        	e.printStackTrace();
            System.exit(1);        	
        }
        finally  {
        	try{
        		buff.close();
        	}
        	catch (IOException ioe) {
        		//don't do anything
        	}
        }   	
    }
    //splits inputline, creates staff object and adds to list of entries
    private void processLine(String inputLine) {
    	String splitString[] = inputLine.split("|");
    	Integer competitorNumber = Integer.parseInt(splitString[0]);

		Name person = new Name(splitString[1]);
		// Check for name errors in file
		if (person.getFirstName() == "" || person.getLastName() == "") {
			// Inform user of name error
			throw new RuntimeException("Error: Name(s) in file invalid.");
		}
		String rank = splitString[2];
		// Check for rank errors in file
		if (rank == "") {
			// Inform user of rank error
			throw new RuntimeException("Error: Rank(s) in file invalid.");
		}
		String teamName = splitString[3];
		// Scores are stored
		Integer[] scores = new Integer[Competitor.NUM_SCORES];
		String[] stringScores = splitString[4].split(",");
		// Score errors dealt with
		if (stringScores.length != Competitor.NUM_SCORES) {
			throw new RuntimeException("Error: Scores in file invalid. Array wrong length.");
		}
		// Populating scores array
		for (int i = 0; i < Competitor.NUM_SCORES; i++) {

			String stringScore = stringScores[i];
			Integer score = Integer.parseInt(stringScore);
			scores[i] = score;
		}
		entries.addOneCompetitor(new DotaCompetitor(competitorNumber, person, rank, teamName, scores));
    }
  
    //show GUIs
    private void showGUI() {
    	//create main GUI with StaffList object
    	CompetitorListGUI gui = new CompetitorListGUI(entries);
        gui.setVisible(true);

    }
    

    public static void main (String arg[]) {
       	//creates demo object which sets up the interface
    	//then just waits for user interaction
    	GUIInteractions demo = new GUIInteractions();   	
    	demo.showGUI();

    }



}
