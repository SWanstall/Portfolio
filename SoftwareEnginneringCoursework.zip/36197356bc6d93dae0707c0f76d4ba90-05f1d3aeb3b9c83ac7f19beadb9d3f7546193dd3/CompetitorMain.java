
/**
 * This class utilises the functions from the Manager class.
 * 
 * @author Simon Wanstall Student Number: H00215317
 */
public class CompetitorMain {

	/**
	 * Main method for the competitor package.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		Manager.managerFunction();

	}

}
