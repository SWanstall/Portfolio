/**
 * This class receives the information for competitors in the dota2Solo category
 * and calculates their scores.
 * 
 * While Dota 2 can be played by teams of 5 people, there are often side events
 * at competitions where single players from those teams will face off against
 * each other one on one. Unlike in the main competition, the victor is not the
 * one who destroys their opponent's base, but the first to score a kill.
 * 
 * @author Simon Wanstall Student Number: H00215317
 *
 */
public class DotaSoloCompetitor extends Competitor {

	/**
	 * Constructor which compiles a competitor's data
	 * 
	 * @param competitorNumber - the competitor's ID number
	 * 
	 * @param competitorName   - the competitor's name
	 * 
	 * @param competitorRank   - the competitor's rank
	 * 
	 * @param teamName         - the competitor's team name
	 * 
	 * @param scores           - the competitor's scores
	 */
	public DotaSoloCompetitor(Integer competitorNumber, Name competitorName, String competitorRank,
			String teamName, Integer[] scores) {
		super(competitorNumber, competitorName, competitorRank, teamName, scores);
	}


	/**
	 * Get method for score array string for users to read
	 * 
	 * @return scoresArray - scores output to array string
	 */
	@Override
	public String getScoreArray() {
		return scores[0] + "," + scores[1] + "," + scores[2] + "," + scores[3] + "," + scores[4];
	}

	/**
	 * Get method which computes and returns the competitor's final score.
	 * 
	 * The competitors are scored on the number of eliminations they receive during
	 * a best of 5 match. This means they will receive either 1 or 0 in each round,
	 * up to a maximum of 3 overall.
	 * 
	 * In order to keep all overall scores equivalent in the super class, these
	 * scores are being divided by 3 so that they can be calculated as a percentage
	 * of the maximum score. They can then be multiplied by 5 to be equivalent to
	 * the scores from the other 3 classes. i.e. 3/3 is 1, multiplied by the maximum
	 * score (5) becomes 5, whereas 2/3 will only receive two thirds of the maximum.
	 * 
	 * @return overallScore - scores divided by 3 then multiplied by 5 to match
	 *         others
	 */
	@Override
	public double getOverallScore() {
		// Determine total score
		double scoresTotal = 0.0;
		for (int scoresIndex = 0; scoresIndex < scores.length; scoresIndex++) {
			scoresTotal += scores[scoresIndex];
		}
		// Find overall score out of 5 by dividing by the highest possible score
		double overall;
		overall = (scoresTotal / 3.0) * 5;
		return overall;

	}
	
	@Override
	CompetitorType getType() {
		return CompetitorType.DOTA_SOLO;
	}
	
}
