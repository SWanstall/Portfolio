/**
 * 
 * This is the super class for all competitor objects.
 * 
 * @author Simon Wanstall Student Number: H00215317
 *
 */
abstract public class Competitor {

	// Instance variables for competitor information
	// Competitor ID number
	protected Integer competitorNumber;
	protected Name competitorName;
	// Competitor rank. Is always a simple string, regardless of category.
	protected String competitorRank;
	// Each 5 person team usually has a wacky name like "Evil Geniuses" or "Team
	// Secret"
	protected String teamName;
	// Length of scores array
	public static final Integer NUM_SCORES = 5;
	protected Integer[] scores;

	/**
	 * Constructor which compiles a competitor's data
	 * 
	 * @param competitorNumber - the competitor's ID number
	 * 
	 * @param competitorName   - the competitor's name
	 * 
	 * @param competitorRank   - the competitor's rank
	 * 
	 * @param teamName         - the competitor's team name
	 */
	public Competitor(Integer competitorNumber, Name competitorName, String competitorRank, String teamName,
			Integer[] scores) {
		this.competitorNumber = competitorNumber;
		this.competitorName = competitorName;
		this.competitorRank = competitorRank;
		this.teamName = teamName;
		this.setScores(scores);
		

	}

	/**
	 * Set method for score array
	 * 
	 * @param scores - integer array of scores
	 */
	public void setScores(Integer[] scores) {
		if (scores.length != NUM_SCORES) {
			throw new IllegalArgumentException(
					"Invalid scores array. Should be size " + NUM_SCORES + " but was " + scores.length);
		}
		this.scores = scores;
	}

	
	/**
	 * Get method for competitor rank.
	 * 
	 * @return competitorRank - the competitor's rank
	 */
	public String getCompetitorRank() {
		return competitorRank;
	}

	/**
	 * Set method for competitor rank.
	 * 
	 * @param competitorRank - the competitor's rank
	 */
	public void setCompetitorRank(String competitorRank) {
		this.competitorRank = competitorRank;
	}

	/**
	 * Get method for competitor ID number
	 * 
	 * @return competitorNumber - the competitor's ID number
	 */
	public Integer getCompetitorNumber() {
		return competitorNumber;
	}

	/**
	 * Get method for team name
	 * 
	 * @return teamName - the competitor's team name
	 */
	public String getTeamName() {
		return teamName;
	}

	/**
	 * Get method for competitor's name
	 * 
	 * @return competitorName - the competitor's name
	 */
	public String getCompetitorName() {
		return competitorName.getFullName();
	}

	/**
	 * Get method which returns the full details of the competitor
	 * 
	 * @return fullDetails - the competitor's full details
	 */
	public String getFullDetails() {
		return "Number: " + competitorNumber + ", Name: " + getCompetitorName() + ", Rank: " + competitorRank
				+ ", Team Name: " + teamName + ", Scores: " + getScoreArray() + ", Final Score: " + getOverallScore();
	}

	/**
	 * Get method which returns the competitor's number, initials and score
	 * 
	 * @return shortDetails - the competitor's short details
	 */
	public String getShortDetails() {
		return competitorNumber + ", " + competitorName.getInitials() + ", " + getOverallScore();
	}

	abstract double getOverallScore();

	abstract String getScoreArray();
	
	abstract CompetitorType getType();

}
