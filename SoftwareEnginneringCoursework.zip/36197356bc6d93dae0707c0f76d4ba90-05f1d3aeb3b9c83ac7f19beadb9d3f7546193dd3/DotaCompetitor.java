/**
 * The intended function of this class is to receive the information of
 * competitors in an online gaming tournament and calculate their final scores.
 * 
 * For the sake of simplicity, let's say the game is Dota 2, a multiplayer
 * online battle arena (MOBA) game. There are 2 teams with 5 players each, and
 * the aim is to destroy the enemy "Ancient", which is heavily defended by
 * sentry towers and waves of monsters.
 * 
 * Teams progress through tournaments if they win, and don't if they lose.
 * However, in game statistics can be used to assess the performances of
 * individual competitors.
 * 
 * @author Simon Wanstall Student Number: H00215317
 */
public class DotaCompetitor extends Competitor {


	/**
	 * Constructor which compiles a competitor's data
	 * 
	 * @param competitorNumber - the competitor's ID number
	 * 
	 * @param competitorName   - the competitor's name
	 * 
	 * @param competitorRank   - the competitor's rank
	 * 
	 * @param teamName         - the competitor's team name
	 * 
	 * @param scores           - the competitor's scores
	 */
	public DotaCompetitor(Integer competitorNumber, Name competitorName, String competitorRank, String teamName,
			Integer[] scores) {
		super(competitorNumber, competitorName, competitorRank, teamName, scores);

	}


	/**
	 * Get method for score array string for users to read
	 * 
	 * @return scoresArray - scores output to array string
	 */
	@Override
	public String getScoreArray() {
		return scores[0] + "," + scores[1] + "," + scores[2] + "," + scores[3] + "," + scores[4];
	}

	/**
	 * Get method which computes and returns the competitor's final score.
	 * 
	 * Losing a game gives no points and winning a game gives a number of points
	 * between 1 and 5 based on level of impact within the team. (i.e. if a
	 * competitor brings their team victory without much help, they will get a 5 and
	 * their team mates will get 1s)
	 * 
	 * A competitor's team must win more than one game for that player to qualify
	 * and earn a score.
	 * 
	 * @return overallScore - average of scores, disregarding maximum and minimum
	 *         values
	 */
	@Override
	public double getOverallScore() {
		// Determine total score
		double scoresTotal = 0;
		for (int scoresIndex = 0; scoresIndex < scores.length; scoresIndex++) {
			scoresTotal += scores[scoresIndex];
		}
		// Determine maximum score value
		int scoresMax = scores[0];
		for (int scoresIndex = 1; scoresIndex < scores.length; scoresIndex++) {
			if (scores[scoresIndex] > scoresMax) {
				scoresMax = scores[scoresIndex];
			}
		}
		// Determine minimum score value
		int scoresMin = scores[0];
		for (int scoresIndex = 1; scoresIndex < scores.length; scoresIndex++) {
			if (scores[scoresIndex] < scoresMin) {
				scoresMin = scores[scoresIndex];
			}
		}

		// Find overall score out of 5.0 by taking the average of the scores,
		// disregarding the highest and lowest
		double overall;
		overall = (scoresTotal - scoresMax - scoresMin) / 3;
		return overall;
	}
	
	@Override
	CompetitorType getType() {
		return CompetitorType.DOTA;
	}

}
