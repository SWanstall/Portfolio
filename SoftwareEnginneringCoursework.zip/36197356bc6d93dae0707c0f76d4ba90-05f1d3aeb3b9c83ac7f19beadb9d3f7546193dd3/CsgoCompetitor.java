/**
 * This class receives the information for competitors in the CSGO category and
 * calculates their scores.
 * 
 * CSGO stands for "Counter Strike: Global Offensive" and is an objective based
 * shooting game with 5 competitors per team. The teams are designated as
 * attackers or defenders at the start and get switched half way through a
 * match.
 * 
 * The objectives for the attackers are either to eliminate all opposing
 * players, or blow up one of two designated zones with a timed explosive. The
 * defenders can also win by eliminating all opposition, but they can otherwise
 * prevent the bomb from being planted, or diffuse the bomb after it has been
 * planted. The first team to win 16 rounds is victorious.
 * 
 * The scores for this competition are calculated by allocating 0.2 points per
 * round won by the team. A small bonus will be added to this score based on
 * ratio of eliminations scored on opposing players, and number of times the
 * competitor has been eliminated. This is commonly named the kill/death or K/D
 * ratio and is a good indicator of whether a player is pulling their weight
 * within the team or not.
 * 
 * @author Simon Wanstall Student Number: H00215317
 *
 */
public class CsgoCompetitor extends Competitor {
	

	// Same as other competitor classes:
	// - Number
	// - Name
	// - Rank (could make different)
	// - Team name

	// Different
	// - Scores
	// - K/D

	/**
	 * Constructor which compiles a competitor's data
	 * 
	 * @param competitorNumber - the competitor's ID number
	 * 
	 * @param competitorName   - the competitor's name
	 * 
	 * @param competitorRank   - the competitor's rank
	 * 
	 * @param teamName         - the competitor's team name
	 * 
	 * @param scores           - the competitor's scores
	 */
	public CsgoCompetitor(Integer competitorNumber, Name competitorName, String competitorRank, String teamName,
			Integer[] scores) {
		super(competitorNumber, competitorName, competitorRank, teamName, scores);

	}

	/**
	 * Get method which computes and returns the competitor's final score.
	 * 
	 * The competitors are scored on how many rounds they have won, plus a bonus
	 * based on how they performed as combatants, up to a total of 5 points.
	 * 
	 * Each round won by the team is worth 0.2 points. Having a K/D ratio lower than
	 * 1 will result in 0 bonus points, a K/D of 1 will bag 0.9 points, and a K/D
	 * higher than 1 will earn 1.8 points.
	 * 
	 * @return overallScore - score from rounds won plus a potential bonus depending on K/D
	 */
	@Override
	public double getOverallScore() {

		// 16 rounds to win game, 16/5 = 3.2 therefore 0.2 points per round won
		// then 0 points for negative K/D, 0.9 for even and 1.8 for positive
		double kdRatio = (scores[2] == 0) ? scores[1]  : scores[1] / scores[2];
		double kdScore = 0;
		if (kdRatio == 1) {
			kdScore = 0.9;
		} else if (kdRatio > 1) {
			kdScore = 1.8;
		}
		// Find overall score out of 5 by multiplying score by 1/5 and adding kdScore 
		double overall;
		overall = scores[0] * 0.2 + kdScore;
		return overall;

	}

	/**
	 * Get method for score array string for users to read (number of rounds won,
	 * kills, deaths).
	 * 
	 * @return scoresArray - scores output to array string
	 */
	@Override
	public String getScoreArray() {
		return scores[0] + "," + scores[1] + "," + scores[2] + "," + 0 + "," + 0;
	}

	@Override
	CompetitorType getType() {
		return CompetitorType.CSGO;
	}

