
public enum CompetitorType {
	
	DOTA_SOLO("Dota 2 Solo"), CSGO("CSGO"), DOTA("Dota 2 Team");
	
	private final String display;
	
	private CompetitorType(String display) {
		this.display = display;
	}
	
	public String getDisplayName() {
		return this.display;
	}
}
