import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * This class gets the competitor information from a file and formats it.
 * 
 * @author Simon Wanstall Student Number: H00215317
 */
public class CompetitorList {
	// Creating competitor ArrayList
	private List<Competitor> competitorList;

	/**
	 * Set method for competitor list.
	 */
	public CompetitorList() {
		competitorList = new ArrayList<>();
	}

	public CompetitorList(List<Competitor> competitorList) {
		this.competitorList = competitorList;
	}

	/**
	 * Method which determines whether a competitor is already in the ArrayList and,
	 * if not, adds them.
	 * 
	 * @param c - competitor
	 * 
	 * @return boolean - to indicate whether competitor was added
	 */
	public boolean addOneCompetitor(Competitor c) {
		Integer competitorNumber = c.getCompetitorNumber();
		Competitor inList = this.findById(competitorNumber);
		if (inList == null) {
			competitorList.add(c);
			return true;
		}
		return false;
	}

	/**
	 * Method which finds a competitor by their ID number.
	 * 
	 * @param competitorNumber - ID number of competitor
	 * 
	 * @return competitor - full details of competitor
	 */
	public Competitor findById(Integer competitorNumber) {
		for (Competitor competitor : this.competitorList) {
			if (competitor.getCompetitorNumber().equals(competitorNumber)) {
				return competitor;
			}
		}
		return null;
	}

	public static CompetitorList mergeLists(CompetitorList... lists) {
		List<Competitor> competitors = new ArrayList<Competitor>();

		for (CompetitorList list : lists) {
			competitors.addAll(list.competitorList);
		}

		return new CompetitorList(competitors);
	}

	/**
	 * Method which reads data from the input file and returns it as full details.
	 * 
	 * @param path - file path
	 * @param type TODO
	 * 
	 * @return competitorList - the ArrayList of competitors, populated from a file
	 * 
	 * @throws IOException - input or output operation failed or was interrupted
	 */
	public static CompetitorList parseFromFile(Path path, CompetitorType type) throws IOException {
		// Get a list of lines from the file
		List<String> competitorStrings = Files.readAllLines(path);
		// Construct a new competitor
		CompetitorList competitorList = new CompetitorList();

		// Loop over lines from file, turn
		// into SLWCompetitors and add to competitors
		for (String competitorString : competitorStrings) {
			// Break string down by the pipe character
			String[] splitString = competitorString.split("\\|");
			// Extract values
			Integer competitorNumber = Integer.parseInt(splitString[0]);

			Name person = new Name(splitString[1]);
			// Check for name errors in file
			if (person.getFirstName() == "" || person.getLastName() == "") {
				// Inform user of name error
				throw new RuntimeException("Error: Name(s) in file invalid.");
			}
			String rank = splitString[2];
			// Check for rank errors in file
			if (rank == "") {
				// Inform user of rank error
				throw new RuntimeException("Error: Rank(s) in file invalid.");
			}
			String teamName = splitString[3];
			// Scores are stored
			Integer[] scores = new Integer[Competitor.NUM_SCORES];
			String[] stringScores = splitString[4].split(",");
			// Score errors dealt with
			if (stringScores.length != Competitor.NUM_SCORES) {
				throw new RuntimeException("Error: Scores in file invalid. Array wrong length.");
			}
			// Populating scores array
			for (int i = 0; i < Competitor.NUM_SCORES; i++) {

				String stringScore = stringScores[i];
				Integer score = Integer.parseInt(stringScore);
				scores[i] = score;
			}

			switch (type) {
			case CSGO:
				competitorList.addOneCompetitor(new CsgoCompetitor(competitorNumber, person, rank, teamName, scores));
				break;
			case DOTA:
				competitorList.addOneCompetitor(new DotaCompetitor(competitorNumber, person, rank, teamName, scores));
				break;
			case DOTA_SOLO:
				competitorList
						.addOneCompetitor(new DotaSoloCompetitor(competitorNumber, person, rank, teamName, scores));
				break;
			default:
				throw new IllegalArgumentException("invalid type " + type.toString());
			}

		}

		return competitorList;

	}

	/**
	 * Get method for ID number of the competitor with the highest score.
	 * 
	 * @return idHi - ID number of competitor with highest score
	 */
	public Integer getIdOfHighestScore() {
		double highestScore = -1;
		Integer idHi = null;
		for (Competitor competitor : this.competitorList) {
			if (competitor.getOverallScore() > highestScore) {
				idHi = competitor.getCompetitorNumber();
				highestScore = competitor.getOverallScore();
			}
		}
		return idHi;
	}

	/**
	 * Get method for ID of competitor with the lowest overall score.
	 * 
	 * @return idLo - ID of competitor with lowest overall score
	 */
	public Integer getIdOfLowestScore() {
		double lowestScore = 5;
		Integer idLo = null;
		for (Competitor competitor : this.competitorList) {
			if (competitor.getOverallScore() < lowestScore) {
				idLo = competitor.getCompetitorNumber();
				lowestScore = competitor.getOverallScore();
			}
		}
		return idLo;
	}

	/**
	 * Get method for total number of competitors in list.
	 * 
	 * @return competitorList.size() - size of competitorList ArrayList
	 */
	public Integer getNumberOfCompetitors() {
		return competitorList.size();
	}

	/**
	 * Get method for an average of all final scores.
	 * 
	 * @return averageOverallScore - the average of all overall scores
	 */
	public float getAverageOverallScore() {
		float ave = 0;
		for (Competitor competitor : this.competitorList) {
			ave += competitor.getOverallScore();
		}
		ave = ave / getNumberOfCompetitors();
		return ave;
	}

	/**
	 * Get method for report of all competitors in table format, plus details of
	 * winner and loser.
	 * 
	 * @return table - full report of all competitors in table format
	 */
	public String getTable() {
		// Assign the ID number of competitor with highest and lowest scores to
		// variables
		Integer idOfHighestScore = getIdOfHighestScore();
		Integer idOfLowestScore = getIdOfLowestScore();
		// Create a simple variable for empty string to allow quick and easy formatting
		String ret = "";
		// Table layout
		ret += "+-----------+----------+------------------------------+--------------------------+------------------------------+--------------------+-------------+-------------+"
				+ "\n";
		// Format the headers of the table by assigning space for each data type
		ret += String.format("|%11s|%10s|%30s|%26s|%30s|%20s|%13s|%13s|", "Game", "ID Number", "Competitor Name",
				"Rank", "Team Name", "Scores", "Overall Score", "Highest Score") + "\n";
		ret += "+-----------+----------+------------------------------+--------------------------+------------------------------+--------------------+-------------+-------------+"
				+ "\n";
		// For each competitor, input data correctly into table using methods from
		// SLWCompetitor
		for (Competitor competitor : this.competitorList) {
			ret += String.format("|%11s|%10d|%30s|%26s|%30s|%20s|%13f|", competitor.getType().getDisplayName(),
					competitor.getCompetitorNumber(), competitor.getCompetitorName(), competitor.getCompetitorRank(),
					competitor.getTeamName(), competitor.getScoreArray(), competitor.getOverallScore());
			// Indicate which competitor has the highest score
			if (competitor.getCompetitorNumber().equals(idOfHighestScore)) {
				ret += " yes         |" + "\n";
			} else {
				ret += " no          |" + "\n";
			}

		}

		ret += "+-----------+----------+------------------------------+--------------------------+------------------------------+--------------------+-------------+-------------+"
				+ "\n";
		// Further summary variables added onto the bottom of the table
		ret += String.format("|%11s|%10s|%30s|%26s|%30s %20s|%13s %13s|", " ", "Total: " + getNumberOfCompetitors(),
				" ", " ", " ", " ", "Ave. Overall:", getAverageOverallScore()) + "\n";
		ret += "+-----------+----------+------------------------------+--------------------------+------------------------------+--------------------+-------------+-------------+"
				+ "\n";
		// Showing full details of winner
		for (Competitor competitor : this.competitorList) {
			if (competitor.getCompetitorNumber().equals(idOfHighestScore)) {
				ret += "The winner is: \n" + competitor.getFullDetails() + "\n";
			}

		}
		// Showing name and score of loser
		// Summary statistic for minimum score
		for (Competitor loser : this.competitorList) {
			if (loser.getCompetitorNumber().equals(idOfLowestScore)) {
				ret += "And the consolation prize goes to: \n" + loser.getCompetitorName() + ", with a score of "
						+ loser.getOverallScore();
			}
		}

		// Return formatted string
		return ret;
	}

	/**
	 * Get method for short report of all competitors in table format, plus details
	 * of winner and loser.
	 * 
	 * @return table - full report of all competitors in table format
	 */
	public String getShortTable() {
		// Assign the ID number of competitor with highest and lowest scores to
		// variables
		Integer idOfHighestScore = getIdOfHighestScore();
		Integer idOfLowestScore = getIdOfLowestScore();
		// Create a simple variable for empty string to allow quick and easy formatting
		String ret = "";
		// Table layout
		ret += "+-----------+------------------------------+" + "\n";
		// Format the headers of the table by assigning space for each data type
		ret += String.format("|%11s|%30s|", "Game", "Short Details") + "\n";
		ret += "+-----------+------------------------------+" + "\n";
		// For each competitor, input data correctly into table using methods from
		// Competitor
		for (Competitor competitor : this.competitorList) {
			ret += String.format("|%11s|%30s|", competitor.getType().getDisplayName(), competitor.getShortDetails());
			// Indicate which competitor has the highest score
			if (competitor.getCompetitorNumber().equals(idOfHighestScore)) {
				ret += " Winner!" + "\n";
			} else {
				ret += " Mediocre Participant" + "\n";
			}

		}

		ret += "+-----------+------------------------------+" + "\n";
		// Further summary variables added onto the bottom of the table
		ret += String.format("|%11s|%30s|", " ", "Total competitors: " + getNumberOfCompetitors()) + "\n";
		ret += "+-----------+------------------------------+" + "\n";
		// Showing full details of winner
		for (Competitor competitor : this.competitorList) {
			if (competitor.getCompetitorNumber().equals(idOfHighestScore)) {
				ret += "The winner is: \n" + competitor.getFullDetails() + "\n";
			}

		}
		// Showing name and score of loser
		// Summary statistic for minimum score
		for (Competitor loser : this.competitorList) {
			if (loser.getCompetitorNumber().equals(idOfLowestScore)) {
				ret += "And the consolation prize goes to: \n" + loser.getCompetitorName() + ", with a score of "
						+ loser.getOverallScore();
			}
		}

		// Return formatted string
		return ret;
	}

}
