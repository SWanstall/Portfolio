#! /usr/bin/env python
# This is code is designed to guide the barista robot around its environment.
# Author: Simon Wanstall

import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
from math import pow, atan2, sqrt
import time


def get_lasers_of_simon_wanstall(msg):
    """This function retrieves laser data from the robot and stores it in a variable."""
    
    # Reference global variables from main
    global left_of_simon_wanstall
    global front_of_simon_wanstall
    global right_of_simon_wanstall
    # Create variable
    all_ranges_of_simon_wanstall = []
    # Append LaserScan.ranges data to variable
    all_ranges_of_simon_wanstall.append(msg.ranges)
    
    # Insert values from ranges
    front_of_simon_wanstall = msg.ranges[360]
    left_of_simon_wanstall = msg.ranges[540]
    right_of_simon_wanstall = msg.ranges[180]
    #print(left_of_simon_wanstall, front_of_simon_wanstall, right_of_simon_wanstall)
    

def get_odometry_data(odom):
    """This function obtains the odometry data from the robot"""
    
    # Reference variables from main
    global linear_x
    global linear_y
    global yaw
    global position

    # Assign Odometry data to corresponding variables
    linear_x = odom.pose.pose.position.x
    linear_y = odom.pose.pose.position.y 
    # Yaw is initially measured in quaternions and must be converted to radians
    yaw = euler_from_quaternion([odom.pose.pose.orientation.x, odom.pose.pose.orientation.y,
        odom.pose.pose.orientation.z, odom.pose.pose.orientation.w])[2]
    # Storing position in global variable
    position = []
    position.append(linear_x)
    position.append(linear_y)
    position.append(yaw)
    print("x, y, yaw")
    print (position)

def get_distance_from_goal(x_goal, y_goal):
    global linear_x
    global linear_y

    return sqrt(pow((x_goal - linear_x), 2) +
            pow((y_goal - linear_y), 2))

def get_linear_velocity (x_goal, y_goal, constant = 1):
    return constant * get_distance_from_goal(x_goal, y_goal)

def get_steering_angle(x_goal, y_goal):
    global linear_x
    global linear_y
    return atan2(y_goal - linear_y, x_goal - linear_x)

def get_angular_velocity(x_goal, y_goal, constant = 1):
    global yaw
    return constant * (get_steering_angle(x_goal, y_goal) - yaw)


def move_and_avoid(left_of_simon_wanstall, front_of_simon_wanstall, right_of_simon_wanstall):

    velocity = Twist()

    # If left is smallest and front is larger than 0.3, robot turns right
    if left_of_simon_wanstall < right_of_simon_wanstall and left_of_simon_wanstall < front_of_simon_wanstall and front_of_simon_wanstall > 0.3:
        velocity.linear.x = 0.08
        velocity.angular.z = -0.22
        return velocity

    # If right is smallest and front is larger than 0.3, robot turns left
    elif right_of_simon_wanstall < left_of_simon_wanstall and right_of_simon_wanstall < front_of_simon_wanstall and front_of_simon_wanstall > 0.3:
        velocity.linear.x = 0.08
        velocity.angular.z = 0.22
        return velocity

    # If front is smaller than 0.3, robot reverses and turns left slightly
    elif front_of_simon_wanstall < 0.3 or left_of_simon_wanstall < 0.4 or right_of_simon_wanstall < 0.4:
        #while right_of_simon_wanstall <= left_of_simon_wanstall:
         #   velocity.linear.x = -0.2
          #  velocity.angular.z = -0.2
        velocity.linear.x = -0.2
        velocity.angular.z = -0.2
        return velocity

    # Else robot will just move forwards
    else:
        velocity.linear.x = 0.2
        velocity.angular.z = 0.0
        return velocity   

def shutdown():

    # Make sure publisher always works within function
    pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
    # Publish Twist messages to halt robot
    velocity = Twist()
    velocity.linear.x = 0.0
    velocity.angular.z = 0.0
    pub.publish(velocity)
    #rospy.signal_shutdown("Destination reached, shutdown signal sent")
    # User feedback
    print ("Shutdown successful. Robot halted.")


def main():
    """This function executes other functions and keeps the program running."""

    # Setup block within main
    # Initiating node
    rospy.init_node('GoTo_', disable_signals = True)
    # Assign global variables for LiDAR
    global left_of_simon_wanstall
    left_of_simon_wanstall = 0
    global front_of_simon_wanstall
    front_of_simon_wanstall = 0
    global right_of_simon_wanstall
    right_of_simon_wanstall = 0
    # Assign global variables for Odometry
    global linear_x
    linear_x = 0
    global linear_y
    linear_y = 0
    global yaw
    yaw = 0
    global position
    position = []
    # Get parameters for goal position
    x_goal = rospy.get_param("x_coordinate")
    y_goal = rospy.get_param("y_coordinate")
    # Set goal tolerance range
    goal_tolerance = 0.5
    # Subscribe to LaserScan and send data to get_lasers
    rospy.Subscriber('/kobuki/laser/scan', LaserScan, get_lasers_of_simon_wanstall)
    # Subscribe to Odometry and send data to get_odometry_data
    rospy.Subscriber('/odom', Odometry, get_odometry_data)
    # Publish velocity messages to topic
    pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
    # Set run rate
    rate = rospy.Rate(5)
    # When ctrl+c pressed, run shutdown function
    rospy.on_shutdown(shutdown)
    
    # Main loop
    while not rospy.is_shutdown():
        while get_distance_from_goal(x_goal, y_goal) >= goal_tolerance:
            
            if left_of_simon_wanstall < 0.6 or front_of_simon_wanstall < 0.6 or right_of_simon_wanstall < 0.6:
                velocity = move_and_avoid(left_of_simon_wanstall, front_of_simon_wanstall, right_of_simon_wanstall)
                pub.publish(velocity)
                rospy.sleep(2.)
            
            #elif 0.35 < left_of_simon_wanstall < 0.6 or 0.35 < front_of_simon_wanstall < 0.6 or 0.35 < right_of_simon_wanstall < 0.6:
             #   velocity = move_and_avoid(left_of_simon_wanstall, front_of_simon_wanstall, right_of_simon_wanstall)
              #  pub.publish(velocity)
                #rospy.sleep(5.)
                
                
            else:

                #rospy.sleep(5.)
                velocity = Twist()
                #velocity.linear.x = 0.2
                velocity.linear.x = 0.1*get_linear_velocity(x_goal, y_goal)
                velocity.angular.z = 0.5*get_angular_velocity(x_goal, y_goal)
                # Return appropriate Twist message based on LiDAR input
                #velocity = move_and_avoid(left_of_simon_wanstall, front_of_simon_wanstall, right_of_simon_wanstall)
                # Publish Twist message to topic 
                pub.publish(velocity)
            rate.sleep() 

        print ("Destination reached")
        velocity = Twist()
        velocity.linear.x = 0
        velocity.angular.z = 0
        pub.publish(velocity)
        rospy.signal_shutdown('Task complete, shutdown initiated')

if __name__=='__main__':
    main()