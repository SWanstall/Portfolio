%% Import and display images
% Importing photoshopped green screen image
testimg = iread('GreenScreenTest.png');
% Display info about image (name, type, resolution, memory size)
about(testimg);
% Display image
idisp(testimg);
% Import background image of the Bahamas
backgroundimg = iread('Background.jpg');
about(backgroundimg);
% Match background image size to green screen image
backgroundimg = isamesize(backgroundimg, testimg); 

% Import overlay image
overlay = iread('Overlay.png');

%% Isolate green (Homework1)
% Define threshold for when pixels are considered to be green
%pixels are green if red < 150 out of 255, blue < 150 and green > 175
greenthresh = (testimg(:,:,1) < 150) & (testimg(:,:,2) > 175) ...
    & (testimg(:,:,3) < 150);

% Loop over red green and blue planes
% Replace green pixels with corresponding background pixels
% Output combined image
output = testimg;
for i = 1:3
    % Isolate red, green or blue plane of testimg depending on i
    plane1 = testimg(:,:,i);
    % Do the same for backgroundimg
    plane2 = backgroundimg(:,:,i);
    % Replace green designated pixels of testimg with corresponding pixels
    %of backgroundimg
    plane1(greenthresh) = plane2(greenthresh);
    % Assign each colour plane to output and build up final image
    output(:,:,i) = plane1;
end
% Display output
idisp(output);
%% Removing outline (Homework1)
% Old threshold could only pick up bright green so values were reduced to
%also isolate dark greens
greenthresh2 = (testimg(:,:,1) < 100) & (testimg(:,:,2) > 100) ...
    & (testimg(:,:,3) < 100);

% Isolating green pixels in output and replacing them with background image
% Could just refine greenthresh to save on computation time but this would
%not be able to identify as many green hues
refinedoutput = testimg;
for i = 1:3
    % Isolate red, green or blue plane of testimg depending on i
    plane1 = output(:,:,i);
    % Do the same for backgroundimg
    plane2 = backgroundimg(:,:,i);
    % Replace pixels of testimg with those of backgroundimg if they fall
    %within the green threshold
    plane1(greenthresh2) = plane2(greenthresh2);
    % Assign isolated colour planes to output and build up final image
    refinedoutput(:,:,i) = plane1;
end
idisp(refinedoutput);

%% Using webcam (Homework3)
% After using webcam support package, access primary webcam
cam = webcam(1);

% Disused method commented out to show progress
% for n = 1:30
%     img = snapshot(cam);
%     greenthresh = (img(:,:,1) < 150) & (img(:,:,2) > 175) ...
%     & (img(:,:,3) < 150);
%     output2 = img;
%     for i = 1:3
%         % Isolate red, green or blue plane of testimg depending on i
%         plane1 = img(:,:,i);
%         % Do the same for backgroundimg
%         plane2 = backgroundimg(:,:,i);
%         % Replace pixels of testimg with those of backgroundimg if they fall
%         %within the green threshold
%         plane1(greenthresh) = plane2(greenthresh);
%         % Assign isolated colour planes to output and build up final image
%         output2(:,:,i) = plane1;
%     end
% idisp(output2);
% end

for n = 1:30
% Take snapshots as frequently as program will allow
img = snapshot(cam);
% Use a gaussian filter to reduce noise
img = imgaussfilt(img);
% Provide an HSV colorspace version of the snapshots for processing
hsv = colorspace('RGB->HSV', img);
% Define threshold for when pixels are considered to be green
% Pixels are green if hue is between 140 and 180 degrees
% Green screen is identified as having more than 40% saturation and more 
%than 30% brightness
truegreen = hsv(:,:,1) >= 140 & hsv(:,:,1) <= 180 ...
    & hsv(:,:,2) >= 0.4 & hsv(:,:,3) >= 0.3;

% Loop over hue, saturation and brightness planes
% Replace green pixels with corresponding background pixels
% Output combined image
output = img;
    for i = 1:3
        % Isolate hue, saturation or brightness plane of img depending on i
        plane1 = img(:,:,i);
        % Do the same for backgroundimg
        plane2 = backgroundimg(:,:,i);
        % Replace pixels of img with those of backgroundimg if they fall
        %within the green threshold
        plane1(truegreen) = plane2(truegreen);
        % Assign isolated HSV planes to output and build up final image
        output(:,:,i) = plane1;
    end
    
% If the user wishes to stop showing webcam footage, they can activate an
%overlay by holding up a checkerboard pattern
% Use detect checkerboard function from caliration assignment
[points, size] = detectCheckerboardPoints(img);
% If a board is detected, the size parameter will be greater than zero
% Noise can create a checkerboard pixel pattern so minimum size upped to 5
    if size(1) >= 5 || size(2) >= 5
        % Once a board is detected, change output to overlay
        output = overlay;
    end
% Display each snapshot as it is processed to make up new video
idisp( output );
end
%% Stop webcam
% Stop any webcam previews
closePreview(cam);
% Halt Matlab's access to webcam
clear('cam');

%% Getting calibration data (Homework2)
% Create a variable for extrinsics
h2=figure; showExtrinsics(cameraParams, 'CameraCentric');
% Set webcam to be a central camera (Robotics, Vision and Control pg.331)
% Input intrinsics from matrix and calculations
cam = CentralCamera('focal', 0.027, 'pixel', 27.8e-6, ...
    'resolution', [1280 720], 'centre', [638.3278 353.1345], ...
    'name', 'mycamera');
% Estimate FOV x and y angles to check against calculations
fov = cam.fov() * 180/pi;
